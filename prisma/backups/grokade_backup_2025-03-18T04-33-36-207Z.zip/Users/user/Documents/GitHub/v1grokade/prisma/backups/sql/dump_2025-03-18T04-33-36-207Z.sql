--
-- PostgreSQL database dump
--

-- Dumped from database version 16.8 (Debian 16.8-1.pgdg120+1)
-- Dumped by pg_dump version 16.8 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."UserRole" AS ENUM (
    'REGULAR',
    'BASIC',
    'AUTHOR',
    'SPONSOR',
    'ADMIN'
);


ALTER TYPE public."UserRole" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: game_favorites; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.game_favorites (
    "userId" text NOT NULL,
    "gameId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.game_favorites OWNER TO postgres;

--
-- Name: game_metrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.game_metrics (
    id text NOT NULL,
    "gameId" text NOT NULL,
    views integer DEFAULT 0 NOT NULL,
    plays integer DEFAULT 0 NOT NULL,
    likes integer DEFAULT 0 NOT NULL,
    dislikes integer DEFAULT 0 NOT NULL,
    "lastUpdated" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.game_metrics OWNER TO postgres;

--
-- Name: games; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.games (
    id text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    "imageUrl" text,
    "playUrl" text NOT NULL,
    "authorId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    tagcategory text,
    xaccount text,
    "galleryImage1" text,
    "galleryImage2" text,
    "galleryImage3" text,
    "galleryImage4" text,
    featured boolean DEFAULT false NOT NULL
);


ALTER TABLE public.games OWNER TO postgres;

--
-- Name: page_views; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.page_views (
    id text NOT NULL,
    path text NOT NULL,
    "userId" text,
    "userAgent" text,
    referer text,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.page_views OWNER TO postgres;

--
-- Name: sponsors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sponsors (
    id text NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    "logoUrl" text NOT NULL,
    website text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.sponsors OWNER TO postgres;

--
-- Name: subscribers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subscribers (
    id text NOT NULL,
    email text NOT NULL,
    name text,
    status text DEFAULT 'active'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.subscribers OWNER TO postgres;

--
-- Name: user_achievements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_achievements (
    id text NOT NULL,
    "userId" text NOT NULL,
    "achievementId" text NOT NULL,
    "unlockedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.user_achievements OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id text NOT NULL,
    username text NOT NULL,
    email text NOT NULL,
    "displayName" text NOT NULL,
    password text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    role public."UserRole" DEFAULT 'REGULAR'::public."UserRole" NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: game_favorites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.game_favorites ("userId", "gameId", "createdAt") FROM stdin;
\.


--
-- Data for Name: game_metrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.game_metrics (id, "gameId", views, plays, likes, dislikes, "lastUpdated") FROM stdin;
568835bc-9c7f-458a-bb04-09c0f574627e	bb935fc4-4063-4709-874a-20e8dd1ba36f	0	0	0	0	2025-03-17 01:36:00.237
4fe1743e-275e-4df3-ad55-492d64ea9809	2964c8d9-953c-41a9-aa4f-653d261d14e6	0	0	0	0	2025-03-17 01:36:00.868
ed11a272-d59c-43ab-b66d-e5e0df044135	3ebb0eb7-753f-4778-8b67-7fd98a94b49c	0	0	0	0	2025-03-17 01:36:01.338
b61eeeb3-22b8-4bb7-8285-d92f41875805	d5fba96c-069e-4242-9206-3d145ccf899a	0	0	0	0	2025-03-17 01:36:01.797
ce2c4863-1e3e-476d-9ac8-0386d1661168	f8279a3a-cbc2-446e-a640-080b05366998	0	0	0	0	2025-03-17 01:36:02.303
025b815e-4d37-42b3-bd08-03ac36493cc1	34734b25-58ec-46ab-ac41-1bceccdab4fa	0	0	0	0	2025-03-17 01:36:03.261
28d759bf-249c-427a-bd27-2a531b994a25	63ecb365-86eb-4c0e-9100-b697c7df6a90	0	0	0	0	2025-03-17 01:36:03.752
f9b26403-c9e4-4f1f-93ef-5710cada4371	8c2d3fdb-bfa7-4838-9e7e-fbe9ca69c12b	0	0	0	0	2025-03-17 01:36:04.249
c00e9d91-cd41-49d4-b1fb-fb0992ba3a69	054009be-8fa3-4bdb-a853-57f5c355583f	0	0	0	0	2025-03-17 19:32:30.487
efc83cb3-bcbc-4246-a944-b677c6f934c7	f68e6594-fe6b-4779-8483-99c510580c6b	2	4	0	0	2025-03-17 19:32:30.487
f516d5fa-e47e-4c57-8a3b-ca6427ec3a24	75d16c0b-6af6-482b-8333-44247339f9e8	0	3	8	2	2025-03-17 19:32:30.487
ff491c9b-6285-4717-b23d-30c9f308ee40	cc4c1e10-ce79-4157-9138-7f59e14ef6fc	5	2	3	1	2025-03-17 19:32:30.487
d569fb08-ee4c-421c-9bdf-0f9ad6031e58	cab0a67a-4967-4c77-901d-12970681ec85	2	1	0	0	2025-03-17 19:33:07.389
a80f7cfd-7c70-4f20-b3b9-a19d0a8cd449	b492c7d1-f9c5-4b3b-a49b-eae4fe82bc83	0	0	0	0	2025-03-17 19:33:07.389
3e789087-c1ad-4e97-8c91-c945e206fa7c	d675ee59-bc51-4acb-a74a-2a51dca64cbe	0	0	9	2	2025-03-17 19:33:24.581
ac610044-309a-45c9-a345-72b4be8d12b0	bbdb0453-4d4d-45ed-ba49-e132cae453f1	0	0	0	0	2025-03-17 01:36:05.626
b9ffc64a-6851-4b86-bd73-b634849a8079	59aee7d1-1d45-4386-a3e4-c164cc4de46d	1	0	1	0	2025-03-17 19:45:34.662
95748756-d27e-4939-a83f-1982c3621da7	e035a8c3-809b-4989-aa39-d5dae607c309	0	0	0	0	2025-03-17 01:36:15.288
3d2b1f29-5a58-44e2-b9c6-038481e2e793	844c3033-7af0-46bc-965f-d7d6c8696660	0	0	0	0	2025-03-17 01:36:17.374
faf61c7c-a30a-46f0-8ad9-1dc04d999998	f7a0e68c-d889-4436-be6a-9f592244ecf0	0	0	0	0	2025-03-17 01:36:17.825
a45e9631-172a-4fdf-b592-e9cca4bd52e3	00bae889-15b5-402f-976e-60f288c8c882	0	0	0	0	2025-03-17 01:36:19.336
2d06ccca-7633-4b9c-9971-4a301f28d12d	b7c322be-7029-435d-baf3-631200ce6ddb	0	0	0	0	2025-03-17 01:36:19.798
497acd1a-8cf3-4964-9dd8-9d647608c479	90dd0c2f-f8cf-47ff-81a5-9613739b59b3	0	0	0	0	2025-03-17 01:36:20.288
634b011a-fb05-4b5d-87ea-5251a857f615	5ab0ce77-3c98-4659-a98f-357d042047d9	0	0	0	0	2025-03-17 01:36:20.748
e233e921-feca-4ab5-8d86-2129fcf3d037	04699df4-76cd-4f84-900a-dd65d5ae7052	0	0	0	0	2025-03-17 01:36:21.266
71ceb01e-3889-4221-9094-b3919c66acd6	7fa78729-6336-441f-8ed6-9c827de2bfe3	0	0	0	0	2025-03-17 01:36:21.786
562dc412-7601-4533-ad7f-27f74a422a28	b98ca5e9-7424-4208-8f0a-dbac8c6ca808	0	0	0	0	2025-03-17 01:36:22.237
e093dd2c-11f6-452c-ba90-c88d1679cf95	219f782b-fed3-4c58-84ec-25f59e930d34	0	0	0	0	2025-03-17 01:36:22.689
ae2f635f-1f7c-4626-816d-ca2d91624382	23f70fdf-049c-4b86-b946-d66ef18d38b4	0	0	0	0	2025-03-17 01:36:23.152
b4f11ab2-926b-4c49-96da-f1704ae57e55	db27129f-f6b4-409d-8d3a-20a590c816f3	0	0	0	0	2025-03-17 01:36:23.63
a8464403-0c2d-46b7-a566-ae7b87348667	b25564d4-e26d-4933-baa4-60d04b385a6a	0	0	0	0	2025-03-17 01:36:24.609
3f899cd8-4dfb-42cb-9546-586e80eec9e4	55887d6d-ef93-44fc-9e0a-afb5cbd83df0	0	0	0	0	2025-03-17 01:36:25.066
2e44786c-3545-4181-b1b2-8cadb4e6aeeb	73875939-a972-4927-b0c6-ae68249bfdb9	0	0	0	0	2025-03-17 01:36:25.54
d4bc6288-cbee-4369-984e-275716f44c09	0af2b647-0e29-4f99-b32f-96501608bf3c	0	0	0	0	2025-03-17 01:36:25.993
f9f59924-ad51-48e1-90fc-b7913c84c695	4aaa007f-ff17-452a-8917-4dd47a8102b4	0	0	0	0	2025-03-17 01:36:26.499
0c31ad29-62d2-4791-a314-5184476caa23	31c831b2-5562-4968-ba09-1a5459bb1b92	0	0	0	0	2025-03-17 01:36:26.96
d60492af-7600-4628-9aa0-9414aa84134e	e5e98736-5eed-4bf3-82d5-fbc29eaaf4b2	0	0	0	0	2025-03-17 01:36:27.433
2e1a2f20-571c-4c70-88f3-46e565f7c686	35096d12-6a4a-4e7a-aed9-19b5db5db10c	0	0	0	0	2025-03-17 01:36:27.885
6d9f25a3-e0a4-463e-a733-999281cbcb3b	eccd75c9-812b-4464-b542-8dc1c4fa94f9	0	0	0	0	2025-03-17 01:36:28.386
d406c5e7-ae7d-42c4-ad98-bd6eb7253a6c	d5114658-91f6-4b1f-834d-be49235e419c	0	0	0	0	2025-03-17 01:36:28.841
7ac9de6c-c8ee-454e-a3d7-f19eb2f4daeb	7854fc02-d82c-4044-a52b-dd01380bfd7d	0	0	0	0	2025-03-17 01:36:29.333
7789a660-8aeb-41a5-88a9-c10fabfdb255	533711da-7205-4171-b1b3-76f725ce4da2	0	0	0	0	2025-03-17 01:36:29.796
fd529450-b068-4738-926c-725edae77de4	2c91becf-3c2b-4692-a762-66caeec53d1e	0	0	0	0	2025-03-17 01:36:30.441
d1dcf6d3-6ee6-4136-9f34-f504966db49f	d41e8753-0ada-4b33-bed9-a688ffa34d9e	0	0	0	0	2025-03-17 01:36:30.913
d07e52f3-08c0-4411-bd38-84fbc3b4fefc	341b131e-4d79-4f7b-82da-bf8174bcceaf	0	0	0	0	2025-03-17 01:36:31.476
d6b16d78-978f-4058-8859-98b1305cb221	4a8a627b-d49e-478c-9a93-d08d4100837a	0	0	0	0	2025-03-17 01:36:31.93
63456f07-9dce-48b3-abf2-b5b4fdb1789a	77261e65-6403-44cf-9f3f-2cc9f3d95f13	0	0	0	0	2025-03-17 01:36:33.425
b01f3212-5d2b-4421-8372-47b9784d2c77	07b92061-6f7f-4355-8be5-7e215deba937	0	0	0	0	2025-03-17 01:36:33.896
ab84769f-4687-46e8-a668-238c68b4bcdf	8b7021c3-73e4-46d9-b84f-b6291be61d3a	0	0	0	0	2025-03-17 01:36:34.379
f0b24095-fe26-4018-ba39-b9e4d169fae3	084cfb0c-2623-48cf-b8d6-2d6d6c0baec1	0	0	0	0	2025-03-17 01:36:34.829
2177231d-eb1f-482a-9d79-cdb4824b9a11	95b4658f-3578-4409-be47-6ec79ff6204f	0	0	0	0	2025-03-17 01:36:35.298
d3efc8d4-393b-4109-a894-6887d54febc2	d801607f-418e-4330-8f75-d947467ce3aa	0	0	0	0	2025-03-17 01:36:35.768
2e566c8a-071b-4865-a78c-0fbce8d52a9f	ba0fa9e9-9eba-403c-be52-2a136ecf3b7a	0	0	0	0	2025-03-17 01:36:36.24
89541790-f081-4551-a1ef-113162d39909	2272eed7-d25d-496f-aece-6aa7cbaac8bd	4	9	21	3	2025-03-17 22:53:14.009
25d71336-ec82-492f-91e3-2db1a79e6bb4	2bc0e5cc-9d7e-438c-b1b3-c963b3c84aec	1	0	0	0	2025-03-18 04:01:26.492
5b4cc16d-a781-4da9-aab4-994a88642798	30cdfe59-56b7-4ea4-8f20-c975698e4541	3	1	1	0	2025-03-17 23:50:56.271
7d8e9ee9-7fed-4ea5-9ccb-730b4b5a3a41	162a11b3-6138-4540-86ae-f50619bac7f4	1	0	1	0	2025-03-17 23:02:31.451
06b5e981-05b2-48db-85d3-ef948a0af728	193935c5-ac96-4664-bcc0-9869b84e1548	2	0	0	0	2025-03-18 00:57:19.289
95c682d7-cce0-4eb6-baaa-0683960ffff0	bf456723-0c50-448d-9732-623f581da6a0	10	0	1	0	2025-03-18 04:30:06.93
9fb1e2be-11a6-4c6e-ba53-41e25bcee833	22845991-0fb6-4bdf-9725-0525b565699c	0	0	0	0	2025-03-17 01:36:36.725
0036efd7-b62b-4312-82d5-ca91e29eb7ab	dfba9261-3270-4ba2-9110-5103eb8c03c9	0	0	0	0	2025-03-17 01:36:37.211
35a40c22-fe74-4079-b2a6-8c4a1378f31e	bcbbaf7b-bd8e-413d-b42b-e483d4dec771	0	0	0	0	2025-03-17 01:36:37.689
2f2a2acb-9c26-4eaa-ada5-eb2f0b0ac9b5	ed450b52-5caa-492f-8790-d3c6b4f77fff	0	0	0	0	2025-03-17 01:36:38.196
a8710d88-3ce4-48b2-ae0f-71f78f5f65d4	f0e24ffc-e714-4da0-8510-35cfbb521ffb	0	0	0	0	2025-03-17 01:36:38.683
6c707f6d-a44f-4e8a-a90a-43ac36133564	8ad6e622-f36f-42e3-aac7-92aa7d3a8288	0	0	0	0	2025-03-17 01:36:39.659
f39c4746-f6c3-4aa2-8819-637d896ee6d4	788597c7-0923-4688-a425-6e694b0007d2	0	0	0	0	2025-03-17 01:36:40.187
7e019a74-3880-4bbc-9cd7-87a2a8080e7f	8759da60-d5ce-42b4-b0aa-fafdbd345aa2	0	0	0	0	2025-03-17 01:36:40.683
fd664fdd-33f7-463f-bcd3-6f55f0ac316c	25754fe0-22d6-4e01-b552-add4be72ae48	0	0	0	0	2025-03-17 01:36:41.197
af8acac7-23a9-4cab-9c18-7341d98eb53e	af707792-b791-4803-9d5d-dd83bf7fcc87	0	0	0	0	2025-03-17 01:36:41.689
4214efa5-ca26-49c0-ad81-9d4712ff3cb5	0b859c68-a877-40a3-9f8e-ca0bc40317b5	0	0	0	0	2025-03-17 01:36:42.174
2584270f-ca09-4772-83d4-9fa7e4690809	f67f4c00-47fa-4ee3-a7bd-8a1bacd6f95e	0	0	0	0	2025-03-17 01:36:42.676
ea3c6dd3-da14-481e-a2ae-a7884d937c5a	9359a360-70c0-43ad-bceb-9912f7d134da	0	0	0	0	2025-03-17 01:36:43.154
3b363df3-a3cf-4807-8129-8a397be8b020	8cfc30a0-f692-4e4e-bdca-ad4c2c372cd1	0	0	0	0	2025-03-17 01:36:43.649
8f526b13-d5f4-4c27-8eb4-13950d02b664	d5663aac-ae60-473b-b36d-d00b4504dcc2	0	0	0	0	2025-03-17 01:36:44.124
2778d65c-0e38-4339-8001-88f3d9f2467b	c10111fb-d178-4643-b837-7ef19bef8f41	0	0	0	0	2025-03-17 01:36:44.687
1f305a70-6825-47b6-9acd-c5d1147f39f6	59b2393e-ebab-4d7e-b9c3-b2aaa0bd8513	0	0	0	0	2025-03-17 01:36:45.167
c89e3026-dd1e-4efe-8d84-2b6019adc7fe	dca78d28-45b4-44ea-9bc7-80baf7008641	0	0	0	0	2025-03-17 01:36:45.8
90b4082a-d615-4b9f-a376-a18a7c3ecdbb	07d6775c-e242-4597-a44e-e22437a49459	0	0	0	0	2025-03-17 01:36:46.304
0b34822f-24bf-4b17-b15d-b9fbb3511e90	16d4082f-5b2f-4528-bc21-c105e46abbdf	0	0	0	0	2025-03-17 01:36:46.791
9a09bc08-4bd9-4b98-b877-3eb81fa5f17e	9748c31e-640b-4263-b719-da3a8f08736e	0	0	0	0	2025-03-17 01:36:47.283
00f2b6f0-5d25-44fb-8efd-f22b197e0616	b4d24777-f913-46b7-983d-88490a68e2c0	0	0	0	0	2025-03-17 01:36:47.74
b867effd-2904-4f6c-8403-533dd9732502	4626e481-051b-4832-ba44-be606da797c6	0	0	0	0	2025-03-17 01:36:48.221
9f31e780-7645-4c61-b52a-aaf08c08f8eb	8f9010c4-d77b-4887-9cc3-0c9b7010c569	0	0	0	0	2025-03-17 01:36:48.753
925b2cbd-4990-4350-9989-13d95e7ad627	6cb521f3-5336-4f75-8bbb-9b67d8b7ba3f	0	0	0	0	2025-03-17 01:36:49.713
bb913823-0dab-4835-bfcb-b8d2e5b9ed4c	83afb8c5-9e23-4fa8-9168-83decbd7978d	0	0	0	0	2025-03-17 01:36:50.219
0121c97c-866c-4d87-b2ae-582da6795d5d	d2bc2c08-c7b5-47b7-b45b-fa3b5b2e8f36	0	0	0	0	2025-03-17 01:36:50.747
54b6f21a-074c-4cb1-af9c-b53191106a01	9b149ef6-7d84-4edc-8283-8b5522ce3518	0	0	0	0	2025-03-17 01:36:51.281
b0664f2d-8f50-4904-bcba-42b18a0588c8	4b3fa1ed-a7fa-4185-9f03-519c76913aca	0	0	0	0	2025-03-17 01:36:52.295
4005687c-749b-48ec-afd7-b5824da47e2b	0dd8000b-48c2-4f63-addc-f4e908dd939e	0	0	0	0	2025-03-17 01:36:53.288
ab4f275b-2a41-48eb-80bb-84da78d4073b	46250f21-9a73-4146-88f4-513a1c5f99d9	0	0	0	0	2025-03-17 01:36:53.774
2647bf0b-b02e-4c4b-98ac-4b8807fc73ab	18b64c24-3028-4d04-98e5-c4382f0c8cd0	0	0	0	0	2025-03-17 01:36:55.732
739795ca-90e3-4e5e-a673-db374e4ddc37	4bebe6a9-db56-453e-a85d-0400cb5a08f5	0	0	0	0	2025-03-17 01:36:56.232
aa508cd1-580e-450c-aacd-203ffcd32da6	61f434ad-2388-45de-b373-b561be63590b	0	0	0	0	2025-03-17 01:36:57.188
ef81b2f7-bc0f-4aae-9ca9-7bbd73210ca2	3e78f568-8737-4c77-a46b-e326470acb70	0	0	0	0	2025-03-17 01:36:57.659
f6b63018-6341-4179-9074-a5c725d5fc36	24d8d342-b1d7-40ee-8ad4-6c5636c04661	0	0	0	0	2025-03-17 01:36:58.122
0b7dbbb7-1bb3-4c8a-b3a2-f4c5c81d43ff	20f4e68a-8d53-454a-a405-d40fa30e4674	6	0	1	0	2025-03-17 04:50:14.735
6092020e-4877-46c0-8838-dbf51cbc74d8	2bfa4820-05e8-429d-91db-fd43914f98f9	1	0	0	0	2025-03-17 04:44:50.099
11fb5f42-4d54-461b-b314-4a22c046ec8c	86c45ba5-ab0f-452b-b1e8-877a898bec14	2	0	0	0	2025-03-17 04:04:21.739
3d097a0a-9052-4e42-941f-f5b91a9070ed	c60de4b9-bb22-4b66-ba31-8a6754f8a876	2	1	0	0	2025-03-17 04:40:55.363
cb25e905-caf4-4024-a5bd-2b498ae2e6bf	a3235777-29c9-418d-8b3d-bec551b9e174	1	0	0	0	2025-03-17 04:50:40.723
eecc0ef9-029d-4ad3-a229-f79281d7f882	408320e2-1adb-470a-b015-6e39bf8a5990	6	6	4	1	2025-03-17 19:31:27.425
3009cc21-95b1-414b-8069-bb06c3862535	91698f39-9bc5-464f-8aaf-e73a8a0f3cea	3	3	0	0	2025-03-17 19:28:35.295
a3b5bf27-3d3d-4eb8-813e-476c615cfc13	1c44b058-5546-4826-ae5b-262763ad2a31	1	12	0	0	2025-03-17 19:33:07.389
88bc106c-7c94-4c5b-a9af-aedbfb4f8f21	8d3ebac9-6a26-4269-96c4-d6da0514d5b1	4	1	0	0	2025-03-17 23:19:35.717
db50a8ac-a94b-47b0-9a10-a7c3bbee20bc	bbbf2d80-4dba-4faf-a777-09cb88159bc1	6	4	0	0	2025-03-18 03:49:58.882
12588c63-94df-453b-9b86-ba7073edad93	7f37cb28-0731-4c2a-b1b9-16cd56a57367	1	0	0	0	2025-03-18 01:02:16.105
fd2567bf-53ad-40d1-bf27-5752a8765812	e0173448-5bdb-410d-a47b-0174bf726c8b	2	0	0	0	2025-03-18 01:21:06.643
c37a5659-ca8d-4149-8beb-96799c6013d9	13a9b6f6-0b5b-416b-ab9e-3e143dd6bfce	6	1	1	0	2025-03-17 23:05:01.069
9f538791-117f-4fcc-b7ef-7028e4d7e3c6	bfbf5cd7-c44b-4054-a1a8-71455c04f29d	2	0	1	0	2025-03-17 22:52:10.504
143b3c84-1748-4b7a-947a-cb5147e8f3fb	708299c8-25f6-45c6-ad30-3dc8592775d4	15	6	2	0	2025-03-18 03:53:15.542
5a78b654-3526-4284-b474-492250442258	8074fbb7-fe43-4c9b-aa2b-839438670652	6	6	0	0	2025-03-18 04:00:10.548
\.


--
-- Data for Name: games; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.games (id, title, description, "imageUrl", "playUrl", "authorId", "createdAt", "updatedAt", tagcategory, xaccount, "galleryImage1", "galleryImage2", "galleryImage3", "galleryImage4", featured) FROM stdin;
cc4c1e10-ce79-4157-9138-7f59e14ef6fc	Dogfight Arena	Pilot WW2 planes in the most exciting and realistic dogfights!	https://res.cloudinary.com/dxow1rafl/image/upload/v1741710493/grokade-screenshots/game_4_1741710492449_Dogfight_Arena_20250310_095322.png.png	https://fly.zullo.fun/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 02:13:30.327	2025-03-16 02:13:30.327	\N	\N	\N	\N	\N	\N	f
cab0a67a-4967-4c77-901d-12970681ec85	Flight Simulator	Flight simulator with great visuals	https://res.cloudinary.com/dxow1rafl/image/upload/v1741710580/grokade-screenshots/game_90_1741710579391_Flight_Simulator_20250310_095558.png.png	https://flyhi.netlify.app/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 02:13:31.786	2025-03-16 02:13:31.786	\N	\N	\N	\N	\N	\N	f
d675ee59-bc51-4acb-a74a-2a51dca64cbe	Santa's Letter Quest	A fun browser game where Santa throws snowballs at ghosts to collect letters and win.	https://res.cloudinary.com/dxow1rafl/image/upload/v1741710568/grokade-screenshots/game_80_1741710567833_Santa_s_Letter_Quest_20250310_095539.png.png	https://www.santasletterquest.com/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 02:13:34.607	2025-03-17 19:43:39.741	Strategy,Puzzle	\N	\N	\N	\N	\N	f
75d16c0b-6af6-482b-8333-44247339f9e8	Moonlanders	Fly anywhere in the world from your Browser, sim test built with AI assistance	\N	https://m.moonlanders.net/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 02:13:33.45	2025-03-16 02:13:33.45	\N	\N	\N	\N	\N	\N	f
f68e6594-fe6b-4779-8483-99c510580c6b	Space Combat	Fight In Space	https://res.cloudinary.com/dxow1rafl/image/upload/v1741710577/grokade-screenshots/game_91_1741710577243_Space_Combat_20250310_095600.png.png	https://spacefightergame.com/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 02:13:35.081	2025-03-16 02:13:35.081	\N	\N	\N	\N	\N	\N	f
d5fba96c-069e-4242-9206-3d145ccf899a	Hot Air Balloon	A visually stunning, multiplayer hot air balloon game set over the Alps.	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171211/grokade-screenshots/Hot_Air_Balloon_Adventure_20250316_155638.png	https://www.hotairvibe.com/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-17 19:45:02.707	Sports,Adventure	https://x.com/SieversJosua	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171211/grokade-screenshots/Hot_Air_Balloon_Adventure_20250316_155638.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171531/grokade-screenshots/Hot_Air_Balloon_Adventure_20250310_203245.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171532/grokade-screenshots/Hot_Air_Balloon_Adventure_20250310_202401.png	\N	f
b492c7d1-f9c5-4b3b-a49b-eae4fe82bc83	Vibe Karting	Karting racing game	https://res.cloudinary.com/dxow1rafl/image/upload/v1741710476/grokade-screenshots/game_3_1741710475505_Vibe_Karting_20250310_095320.png.png	https://vibekarting.com/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 02:13:36.504	2025-03-16 02:13:36.504	\N	\N	\N	\N	\N	\N	f
bb935fc4-4063-4709-874a-20e8dd1ba36f	Antsantsants	You are an ant. You can dig.	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171206/grokade-screenshots/Antsantsants_20250310_203309.png	https://antsantsants.xyz	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Arcade,Shooter,Sports	https://x.com/ranking091	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171206/grokade-screenshots/Antsantsants_20250310_203309.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171513/grokade-screenshots/Antsantsants_20250316_155749.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171514/grokade-screenshots/Antsantsants_20250310_202445.png	\N	f
2964c8d9-953c-41a9-aa4f-653d261d14e6	Car vs Monsters	Drive through the city while avoiding or confronting monsters. Collect power-ups to survive longer and defeat enemies!	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171208/grokade-screenshots/Car_vs_Monsters_20250310_203205.png	https://3d-racer.netlify.app/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Racing,Shooter,Simulation	https://x.com/markszymik	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171208/grokade-screenshots/Car_vs_Monsters_20250310_203205.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171517/grokade-screenshots/Car_vs_Monsters_20250316_155805.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171518/grokade-screenshots/Car_vs_Monsters_20250310_202335.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171520/grokade-screenshots/Car_vs_Monsters_20250316_155546.png	f
3ebb0eb7-753f-4778-8b67-7fd98a94b49c	ShooterWorldAI	Multiplayer FPS Game	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171209/grokade-screenshots/ShooterWorldAI_20250316_155913.png	https://shooterworldai.com/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Shooter,Action	https://x.com/FeineCapital	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171209/grokade-screenshots/ShooterWorldAI_20250316_155913.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171525/grokade-screenshots/ShooterWorldAI_20250316_155508.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171527/grokade-screenshots/ShooterWorldAI_20250310_203233.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171528/grokade-screenshots/ShooterWorldAI_20250310_202438.png	f
f8279a3a-cbc2-446e-a640-080b05366998	Word Smash	Fun Typing Challenge Game	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171213/grokade-screenshots/Word_Smash_20250316_155852.png	https://wordsmash.apsquared.co	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Arcade,Puzzle,Sports	https://x.com/apsquareddev	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171213/grokade-screenshots/Word_Smash_20250316_155852.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171535/grokade-screenshots/Word_Smash_20250316_155937.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171536/grokade-screenshots/Word_Smash_20250310_203347.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171538/grokade-screenshots/Word_Smash_20250310_202326.png	f
34734b25-58ec-46ab-ac41-1bceccdab4fa	Grid Golf		https://res.cloudinary.com/dxow1rafl/image/upload/v1742171215/grokade-screenshots/Grid_Golf_20250316_160020.png	https://gridgolf.netlify.app/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Sports,Arcade,Platform	https://x.com/byteonwire	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171215/grokade-screenshots/Grid_Golf_20250316_160020.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171547/grokade-screenshots/Grid_Golf_20250310_203339.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171548/grokade-screenshots/Grid_Golf_20250310_202444.png	\N	f
63ecb365-86eb-4c0e-9100-b697c7df6a90	Pirate and fishing game	Basically you go around and fish and there are monsters that attack you	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171217/grokade-screenshots/Pirate_and_fishing_game_20250310_203158.png	https://boats.dyoburon.com/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Racing	https://x.com/dyoburon	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171217/grokade-screenshots/Pirate_and_fishing_game_20250310_203158.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171552/grokade-screenshots/Pirate_and_fishing_game_20250310_202333.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171553/grokade-screenshots/Pirate_and_fishing_game_20250316_155725.png	\N	f
8c2d3fdb-bfa7-4838-9e7e-fbe9ca69c12b	Boat Race 3D	You drive a boat around Santorini topography, shoot at other boats and listen to cool music	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171219/grokade-screenshots/Boat_Race_3D_20250316_155745.png	https://boatrace3d.com/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Racing,Action,Shooter	https://x.com/codefun_xyz	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171219/grokade-screenshots/Boat_Race_3D_20250316_155745.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171556/grokade-screenshots/Boat_Race_3D_20250316_155934.png	\N	\N	f
30cdfe59-56b7-4ea4-8f20-c975698e4541	Freight Frenzy	Trucking themed endless runner	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171221/grokade-screenshots/Freight_Frenzy_20250310_202526.png	https://freightgames.github.io/Freight-Frenzy/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Arcade,Platform,Racing	https://x.com/StephenRuhe	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171221/grokade-screenshots/Freight_Frenzy_20250310_202526.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171559/grokade-screenshots/Freight_Frenzy_20250316_160025.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171560/grokade-screenshots/Freight_Frenzy_20250316_155943.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171561/grokade-screenshots/Freight_Frenzy_20250310_203154.png	f
bbdb0453-4d4d-45ed-ba49-e132cae453f1	Duke Nukem 3D 2025	It's time to kick ass and chew bubble gum.	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171222/grokade-screenshots/Duke_Nukem_3D_2025_20250310_202519.png	https://duke.jobboardsearch.com/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-17 19:43:13.146	Adventure	\N	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171222/grokade-screenshots/Duke_Nukem_3D_2025_20250310_202519.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171564/grokade-screenshots/Duke_Nukem_3D_2025_20250316_155622.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171565/grokade-screenshots/Duke_Nukem_3D_2025_20250316_155839.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171566/grokade-screenshots/Duke_Nukem_3D_2025_20250316_155557.png	f
e035a8c3-809b-4989-aa39-d5dae607c309	8 pool	AI pool game	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171237/grokade-screenshots/8_pool_20250316_155748.png	https://mrdeex.github.io/8pool/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Sports,Arcade	https://x.com/MrDee	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171237/grokade-screenshots/8_pool_20250316_155748.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171662/grokade-screenshots/8_pool_20250310_202506.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171663/grokade-screenshots/8_pool_20250316_155724.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171665/grokade-screenshots/8_pool_20250310_203211.png	f
844c3033-7af0-46bc-965f-d7d6c8696660	PokeBattle Arena	PokeBattle Arena is a lightweight, turn-based battler where you pick a Pokémon from a random lineup and square off against a surprise opponent. Built using Rep...	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171240/grokade-screenshots/PokeBattle_Arena_20250316_155611.png	https://poke-battle-arena.replit.app/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Fighting,Action	https://x.com/rajkstats	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171240/grokade-screenshots/PokeBattle_Arena_20250316_155611.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171695/grokade-screenshots/PokeBattle_Arena_20250310_203221.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171696/grokade-screenshots/PokeBattle_Arena_20250310_202421.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171698/grokade-screenshots/PokeBattle_Arena_20250316_155519.png	f
0b859c68-a877-40a3-9f8e-ca0bc40317b5	Cybertrucksim	A driving game where you and your buddies can cruise in a Cybertruck!	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171304/grokade-screenshots/Cybertrucksim_20250310_202404.png	https://cybertrucksim.com/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Racing,Simulation	https://x.com/Hi_Bennie	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171304/grokade-screenshots/Cybertrucksim_20250310_202404.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171984/grokade-screenshots/Cybertrucksim_20250310_203337.png	\N	\N	f
bf456723-0c50-448d-9732-623f581da6a0	Dome Farm	Chill farming game on Mars. Build your own farm and grow your zen.	https://res.cloudinary.com/dxow1rafl/image/upload/v120250316/grokade-screenshots/Dome_Farm_20250316_154637.png	https://dome.jelmerdeboer.nl/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-17 22:06:50.952	Strategy	https://x.com/jelmerdeboer	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171686/grokade-screenshots/Dome_Farm_20250310_202303.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171688/grokade-screenshots/Dome_Farm_20250316_154637.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171690/grokade-screenshots/Dome_Farm_20250316_160221.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171691/grokade-screenshots/Dome_Farm_20250310_202608.png	t
f7a0e68c-d889-4436-be6a-9f592244ecf0	Builder	Calm, Minecraft like builder game	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171242/grokade-screenshots/Builder_20250316_155701.png	https://www.regame.io	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Strategy,Survival	https://x.com/sarperdag	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171242/grokade-screenshots/Builder_20250316_155701.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171702/grokade-screenshots/Builder_20250310_203325.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171703/grokade-screenshots/Builder_20250316_155613.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171705/grokade-screenshots/Builder_20250310_202423.png	f
162a11b3-6138-4540-86ae-f50619bac7f4	cowboy shooter	A free-to-play 3D runner shooting game, 100% AI-generated, from game assets to code vibe coded by @pseudokid, Cursor AI, Anthropic's Claude 3.7 Sonnet 3D assets...	https://res.cloudinary.com/dxow1rafl/image/upload/v120250316/grokade-screenshots/cowboy_shooter_20250316_154541.webp	https://cowboy.raymelon.com/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-16 22:46:57.149	Action,Shooter,Platform	https://x.com/pseudokid	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171713/grokade-screenshots/Cowboy_Shooter_20250316_155637.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171715/grokade-screenshots/Cowboy_Shooter_20250316_160104.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171716/grokade-screenshots/cowboy_shooter_20250310_200904.jpg	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171717/grokade-screenshots/cowboy_shooter_20250316_154541.jpg	f
00bae889-15b5-402f-976e-60f288c8c882	Classic Pong Game	A classic pong game vibe coding built.	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171243/grokade-screenshots/Classic_Pong_Game_20250310_203327.png	https://maekitgames.com/pong	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Arcade,Sports	https://x.com/vibecoding_	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171243/grokade-screenshots/Classic_Pong_Game_20250310_203327.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171723/grokade-screenshots/Classic_Pong_Game_20250316_155857.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171724/grokade-screenshots/Classic_Pong_Game_20250310_202507.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171726/grokade-screenshots/Classic_Pong_Game_20250316_155910.png	f
b7c322be-7029-435d-baf3-631200ce6ddb	Word God	From Void to Universe. Eginning with primordial concepts, evolve a unique glorious universe through your ability to combine words. Watch your creation grow and ...	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171245/grokade-screenshots/Word_God_20250310_202427.png	https://www.experimentswithai.com/word-god-mindfulness-game.html	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Puzzle,Adventure	https://x.com/edwinhayward	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171245/grokade-screenshots/Word_God_20250310_202427.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171730/grokade-screenshots/Word_God_20250310_203223.png	\N	\N	f
90dd0c2f-f8cf-47ff-81a5-9613739b59b3	Astro Breaker	High-energy First Person Shooter that blends explosive arcade action with precision physics-based gameplay.	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171246/grokade-screenshots/Astro_Breaker_20250310_203302.png	https://hytopia.com/games/astro-breaker/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Action,Shooter,Arcade	https://x.com/NeuralPixelAI	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171246/grokade-screenshots/Astro_Breaker_20250310_203302.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171734/grokade-screenshots/Astro_Breaker_20250310_202347.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171737/grokade-screenshots/Astro_Breaker_20250316_155836.png	\N	f
5ab0ce77-3c98-4659-a98f-357d042047d9	Star Wing	Star Wing is a 3D spaceship shooter built with Three.js for web browsers. The player controls a lone starfighter pilot in a game that blends classic arcade shoo...	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171248/grokade-screenshots/Star_Wing_20250316_155832.png	https://star-wing-drosshole.vercel.app	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Action,Arcade,Fighting	https://x.com/drosshole	\N	\N	\N	\N	f
04699df4-76cd-4f84-900a-dd65d5ae7052	Pork Droid	Retro like asteroids game with a modern twist	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171250/grokade-screenshots/Pork_Droid_20250310_202451.png	https://PorkDroid.com	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Arcade,Action,Shooter	https://x.com/reignboat	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171250/grokade-screenshots/Pork_Droid_20250310_202451.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171740/grokade-screenshots/Pork_Droid_20250316_155808.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171741/grokade-screenshots/Pork_Droid_20250310_203218.png	\N	f
7fa78729-6336-441f-8ed6-9c827de2bfe3	Asteroid Assault	Asteroid shooter arcade game	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171251/grokade-screenshots/Asteroid_Assault_20250310_202503.png	https://asteroid-ep9.pages.dev/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Arcade,Shooter,Action	https://x.com/NoFlinch	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171251/grokade-screenshots/Asteroid_Assault_20250310_202503.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171743/grokade-screenshots/Asteroid_Assault_20250310_203359.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171745/grokade-screenshots/Asteroid_Assault_20250316_155553.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171746/grokade-screenshots/Asteroid_Assault_20250316_155633.png	f
13a9b6f6-0b5b-416b-ab9e-3e143dd6bfce	Land the Booster V3	Land the booster on mars - powerful rocket, fire thrusters, and nail the perfect landing. Can you master the challenge?	https://res.cloudinary.com/dxow1rafl/image/upload/v1742251043/f_tvuqZy_nmrqdn.jpg	https://land-the-booster.s13k.dev/mars/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-17 22:40:01.706	Exploration,Puzzle,Shooter	https://x.com/s13k_	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171706/grokade-screenshots/Land_the_Booster_V2_20250316_155915.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171708/grokade-screenshots/Land_the_Booster_V2_20250310_203307.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171710/grokade-screenshots/Land_the_Booster_V2_20250310_202435.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171712/grokade-screenshots/Land_the_Booster_V2_20250316_155859.png	t
b98ca5e9-7424-4208-8f0a-dbac8c6ca808	ClaudeSpace	Survive the cosmos in ClaudeSpace: dodge asteroids, blast enemies, and master your ship's weapons in this high-speed space shooter.	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171253/grokade-screenshots/ClaudeSpace_20250316_155834.png	https://ladegeraet.github.io/claudespace/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Shooter,Action,Racing	https://x.com/Oho_name	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171253/grokade-screenshots/ClaudeSpace_20250316_155834.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171751/grokade-screenshots/ClaudeSpace_20250310_202539.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171752/grokade-screenshots/ClaudeSpace_20250316_155529.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171754/grokade-screenshots/ClaudeSpace_20250316_155850.png	f
219f782b-fed3-4c58-84ec-25f59e930d34	Gladiator Arena	three.js gladiator arena with your own gladiator and several weapons to choose from. Will receive regular updates so check out often to see what's new.	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171255/grokade-screenshots/Gladiator_Arena_20250310_203321.png	https://3js-arena-v5-long-fog-3116.fly.dev/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Fighting,Shooter	https://x.com/rfitzpatrick_io	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171255/grokade-screenshots/Gladiator_Arena_20250310_203321.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171762/grokade-screenshots/Gladiator_Arena_20250310_202425.png	\N	\N	f
23f70fdf-049c-4b86-b946-d66ef18d38b4	Super Jumper	Jump , Take Boost, Play and get to Finish Line	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171257/grokade-screenshots/Super_Jumper_20250316_155835.png	https://super-jumper-game.web.app/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Platform	https://x.com/nishant_ty	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171257/grokade-screenshots/Super_Jumper_20250316_155835.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171764/grokade-screenshots/Super_Jumper_20250310_202403.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171765/grokade-screenshots/Super_Jumper_20250316_155506.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171766/grokade-screenshots/Super_Jumper_20250310_203206.png	f
db27129f-f6b4-409d-8d3a-20a590c816f3	Formula Simulator Racing	Experience the thrill of high-speed racing in this immersive 3D Formula racing simulator! Race through a dynamic open world filled with challenging obstacles, c...	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171258/grokade-screenshots/Formula_Simulator_Racing_20250316_160004.png	https://racing-car-game.onrender.com/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Simulation,Sports,Arcade	https://x.com/emreozdiyar	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171258/grokade-screenshots/Formula_Simulator_Racing_20250316_160004.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171770/grokade-screenshots/Formula_Simulator_Racing_20250310_202524.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171771/grokade-screenshots/Formula_Simulator_Racing_20250316_155658.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171773/grokade-screenshots/Formula_Simulator_Racing_20250310_203255.png	f
b25564d4-e26d-4933-baa4-60d04b385a6a	Pong Arcade	Challenge the AI or play against a friend in this modern recreation of Pong.	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171259/grokade-screenshots/Pong_Arcade_20250316_155549.png	https://www.pongarcade.com/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Arcade,Puzzle,Racing	https://x.com/mischeiwiller	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171259/grokade-screenshots/Pong_Arcade_20250316_155549.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171788/grokade-screenshots/Pong_Arcade_20250310_203346.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171789/grokade-screenshots/Pong_Arcade_20250316_155644.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171791/grokade-screenshots/Pong_Arcade_20250316_160000.png	f
55887d6d-ef93-44fc-9e0a-afb5cbd83df0	Dyson Defender	Defend the Dyson sphere from waves of alien invaders!	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171261/grokade-screenshots/Dyson_Defender_20250310_203358.png	https://dyson-defender.vercel.app/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Arcade	https://x.com/hankofalltrades	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171261/grokade-screenshots/Dyson_Defender_20250310_203358.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171795/grokade-screenshots/Dyson_Defender_20250316_160112.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171797/grokade-screenshots/Dyson_Defender_20250310_202411.png	\N	f
73875939-a972-4927-b0c6-ae68249bfdb9	AI Bomber Game	Inspired by bomberman, with 3D touches and twists	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171263/grokade-screenshots/AI_Bomber_Game_20250310_203216.png	https://bomberman-bice.vercel.app/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Racing	https://x.com/tuantruong	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171263/grokade-screenshots/AI_Bomber_Game_20250310_203216.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171801/grokade-screenshots/AI_Bomber_Game_20250316_155554.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171803/grokade-screenshots/AI_Bomber_Game_20250310_202536.png	\N	f
0af2b647-0e29-4f99-b32f-96501608bf3c	Cops and Robbers	Either be Robber who has to steal money or play as a cop who catches robbers. More like GTA and NFS.	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171265/grokade-screenshots/Cops_and_Robbers_20250310_202501.png	https://cnr.khatarnakishan.com/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Racing,Arcade,Shooter	https://x.com/Khatarnak_Ishan	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171265/grokade-screenshots/Cops_and_Robbers_20250310_202501.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171805/grokade-screenshots/Cops_and_Robbers_20250316_155607.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171807/grokade-screenshots/Cops_and_Robbers_20250316_155606.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171808/grokade-screenshots/Cops_and_Robbers_20250310_203342.png	f
4aaa007f-ff17-452a-8917-4dd47a8102b4	Wing Man	Fly a hang-glider	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171266/grokade-screenshots/Wing_Man_20250316_155617.png	https://hugohamelcom.github.io/wing-man-game/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Adventure,Racing,Shooter	https://x.com/hugohamelcom	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171266/grokade-screenshots/Wing_Man_20250316_155617.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171814/grokade-screenshots/Wing_Man_20250310_202418.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171815/grokade-screenshots/Wing_Man_20250310_203200.png	\N	f
31c831b2-5562-4968-ba09-1a5459bb1b92	Bubble Basher	Fast paced, pick up and play, multiplayer bubble bashing	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171268/grokade-screenshots/Bubble_Basher_20250316_155942.png	https://bubblebasher.com	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Racing	https://x.com/JonathanACaruso	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171268/grokade-screenshots/Bubble_Basher_20250316_155942.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171818/grokade-screenshots/Bubble_Basher_20250316_155851.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171819/grokade-screenshots/Bubble_Basher_20250316_155914.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171821/grokade-screenshots/Bubble_Basher_20250316_155657.png	f
e5e98736-5eed-4bf3-82d5-fbc29eaaf4b2	VybeRace	VybeRace is a fun, simple racing game with textured roads and scenic trees. Drift off-road to leave tire marks and feel the realistic slowdown—aim to be the f...	https://res.cloudinary.com/dxow1rafl/image/upload/v120250316/grokade-screenshots/VybeRace_20250316_154645.png	https://vibegames.cc/browse/vyberace	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-16 22:46:57.149	Racing,Simulation,Arcade	https://x.com/AlbertSimonDev	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171826/grokade-screenshots/VybeRace_20250316_160228.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171828/grokade-screenshots/VybeRace_20250316_155641.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171830/grokade-screenshots/VybeRace_20250316_155939.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171832/grokade-screenshots/VybeRace_20250316_155812.png	f
35096d12-6a4a-4e7a-aed9-19b5db5db10c	Planetary	Explore space, get into dogfights, do spaceflight time trials	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171269/grokade-screenshots/Planetary_20250316_155706.png	https://magnificent-zabaione-675839.netlify.app/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Strategy,Adventure,Exploration	https://x.com/jbelevate	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171269/grokade-screenshots/Planetary_20250316_155706.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171842/grokade-screenshots/Planetary_20250310_202459.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171844/grokade-screenshots/Planetary_20250310_203152.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171846/grokade-screenshots/Planetary_20250316_155722.png	f
d5114658-91f6-4b1f-834d-be49235e419c	Space Force: Drain The Swamp	Take to the stars as Donald Trump or Elon Musk in Space Force: Drain The Swamp, a thrilling Galaxian-inspired space shooter where patriotism meets intergalactic...	\N	https://hcbgreatwall.itch.io/space-force-drain-the-swamp	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Action,Shooter,Arcade	https://x.com/HCBGreatWall	\N	\N	\N	\N	f
533711da-7205-4171-b1b3-76f725ce4da2	Rock Water Skipping	A fun free-to-play Rock skipping primitive arcade game with real physics 100% made with AI, without any loading screen or game updates, "Just works".	\N	https://rock-water-skipping.vercel.app/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Arcade,Simulation	https://x.com/Stianwalgermo	\N	\N	\N	\N	f
2c91becf-3c2b-4692-a762-66caeec53d1e	Dune Wanderer	Wander the dessert in search of wells	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171272/grokade-screenshots/Dune_Wanderer_20250310_203252.png	https://dunewanderer.com/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Platform	https://x.com/balt1794	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171272/grokade-screenshots/Dune_Wanderer_20250310_203252.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171861/grokade-screenshots/Dune_Wanderer_20250310_202351.png	\N	\N	f
d41e8753-0ada-4b33-bed9-a688ffa34d9e	Emoji Sim	A village of emojis at your command. Create your own villages and even build out your game rules. Learn from others and lead your villagers	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171273/grokade-screenshots/Emoji_Sim_20250316_155811.png	https://emojisim.com/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Simulation,Strategy,Exploration	https://x.com/benwmaddox	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171273/grokade-screenshots/Emoji_Sim_20250316_155811.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171863/grokade-screenshots/Emoji_Sim_20250310_203241.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171864/grokade-screenshots/Emoji_Sim_20250310_202328.png	\N	f
341b131e-4d79-4f7b-82da-bf8174bcceaf	Artillery Defense	Defend your base by shooting down enemy paratroopers	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171275/grokade-screenshots/Artillery_Defense_20250316_155849.png	https://www.craygen.com/artillery/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Action,Shooter	https://x.com/craygen9	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171275/grokade-screenshots/Artillery_Defense_20250316_155849.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171867/grokade-screenshots/Artillery_Defense_20250316_155848.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171868/grokade-screenshots/Artillery_Defense_20250310_203253.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171870/grokade-screenshots/Artillery_Defense_20250310_202449.png	f
7854fc02-d82c-4044-a52b-dd01380bfd7d	Rocklight	Rogue-like shooter	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171271/grokade-screenshots/Rocklight_20250316_155838.png	https://zumashtm.manus.space/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-17 19:43:00.267	Platform,Shooter,Action	https://x.com/skifull579	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171271/grokade-screenshots/Rocklight_20250316_155838.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171859/grokade-screenshots/Rocklight_20250316_155912.png	\N	\N	f
4a8a627b-d49e-478c-9a93-d08d4100837a	TideFall	Build alliances, claim vast lands, and hunt for loot in dangerous realms.	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171276/grokade-screenshots/TideFall_20250310_202414.png	https://tidefall.io	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Exploration,Shooter,Strategy	https://x.com/dyoburon	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171276/grokade-screenshots/TideFall_20250310_202414.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171873/grokade-screenshots/TideFall_20250310_203243.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171874/grokade-screenshots/TideFall_20250316_160109.png	\N	f
2bc0e5cc-9d7e-438c-b1b3-c963b3c84aec	Space Cruise	3D Space Travel Web Game	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171279/grokade-screenshots/Space_Cruise_20250316_155616.png	https://space-cruise.tech	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Action	https://x.com/Aditya_T007	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171279/grokade-screenshots/Space_Cruise_20250316_155616.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171877/grokade-screenshots/Space_Cruise_20250310_203319.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171878/grokade-screenshots/Space_Cruise_20250316_155703.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171879/grokade-screenshots/Space_Cruise_20250316_155936.png	f
59aee7d1-1d45-4386-a3e4-c164cc4de46d	Drone Simulator	Fly different environments with a drone, explore and complete missions	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171280/grokade-screenshots/Drone_Simulator_20250316_155729.png	https://www.iamvg.space/drone-simulator/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Simulation,Exploration,Racing	https://x.com/ged_ven	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171280/grokade-screenshots/Drone_Simulator_20250316_155729.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171885/grokade-screenshots/Drone_Simulator_20250316_160022.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171887/grokade-screenshots/Drone_Simulator_20250316_155631.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171888/grokade-screenshots/Drone_Simulator_20250316_155630.png	f
77261e65-6403-44cf-9f3f-2cc9f3d95f13	3D Tetris	A 3D version of the classic Tetris game where you clear entire platforms	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171281/grokade-screenshots/3D_Tetris_20250316_155802.png	https://3d-tetris-platforms.lovable.app/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Platform,Arcade	https://x.com/RealFredericVC	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171281/grokade-screenshots/3D_Tetris_20250316_155802.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171892/grokade-screenshots/3D_Tetris_20250316_155803.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171893/grokade-screenshots/3D_Tetris_20250316_160106.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171895/grokade-screenshots/3D_Tetris_20250310_203202.png	f
07b92061-6f7f-4355-8be5-7e215deba937	Elemental Combatant	Elemental CombaTanks is a battlefield brawler where you command a tank powered by the elements—fire, water, earth, and air. And more Mode are added.	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171283/grokade-screenshots/Elemental_Combatant_20250316_155933.png	https://asalt.vercel.app	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Action,Fighting,Shooter	https://x.com/IsaacXVoxel	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171283/grokade-screenshots/Elemental_Combatant_20250316_155933.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171902/grokade-screenshots/Elemental_Combatant_20250310_203235.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171905/grokade-screenshots/Elemental_Combatant_20250310_202452.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171907/grokade-screenshots/Elemental_Combatant_20250316_155635.png	f
8b7021c3-73e4-46d9-b84f-b6291be61d3a	Society Fail	Can you survive the apocalypse? Society Fail is a post-apocalyptic incremental game where you must scavenge for resources, fight off mutants, and navigate a wor...	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171286/grokade-screenshots/Society_Fail_20250310_202541.png	https://society.fail/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Survival,Exploration,Strategy	https://x.com/Shpigford	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171286/grokade-screenshots/Society_Fail_20250310_202541.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171911/grokade-screenshots/Society_Fail_20250310_203214.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171912/grokade-screenshots/Society_Fail_20250316_160020.png	\N	f
084cfb0c-2623-48cf-b8d6-2d6d6c0baec1	Flappi Bird	A ThreeJS based Flappi Bird game built completely using Grok3, Claude 3.5, and Cursor.  Along with other AI tools for models, music, graphics, etc	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171287/grokade-screenshots/Flappi_Bird_20250310_203328.png	https://flappi-bird.vercel.app/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Arcade,Sports	https://x.com/joshuajohnsonAI	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171287/grokade-screenshots/Flappi_Bird_20250310_203328.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171916/grokade-screenshots/Flappi_Bird_20250310_202534.png	\N	\N	f
95b4658f-3578-4409-be47-6ec79ff6204f	Fruit of the Boom	Collect as many fruit as you can.	\N	https://isaacdozier.github.io/fruit-of-the-boom/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Arcade,Sports	https://x.com/isaactdozier	\N	\N	\N	\N	f
d801607f-418e-4330-8f75-d947467ce3aa	Island Adventure	Search for treasures and craft items on a island in singleplayer mode	https://res.cloudinary.com/dxow1rafl/image/upload/v120250316/grokade-screenshots/Island_20250316_154543.webp	https://ja.sperdeboer.nl/island/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-16 22:46:57.149	Exploration,Adventure,Survival	https://x.com/jasperdeboer	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171223/grokade-screenshots/Island_Adventure_20250310_202510.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171607/grokade-screenshots/Island_Adventure_20250310_203353.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171608/grokade-screenshots/Island_Adventure_20250316_155750.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171613/grokade-screenshots/Island_Adventure_20250316_155456.png	f
ba0fa9e9-9eba-403c-be52-2a136ecf3b7a	Suika Game	Fuit-merging game akin to tetris or puyo-puyo. built with cursor/claude	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171289/grokade-screenshots/Suika_Game_20250316_155639.png	https://suika.live/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Puzzle	https://x.com/andrwhcom	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171289/grokade-screenshots/Suika_Game_20250316_155639.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171926/grokade-screenshots/Suika_Game_20250310_203227.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171928/grokade-screenshots/Suika_Game_20250310_202408.png	\N	f
22845991-0fb6-4bdf-9725-0525b565699c	Snake Trae	Play classic snake	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171290/grokade-screenshots/Snake_Trae_20250316_160017.png	https://trae.com/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Arcade	https://x.com/traemikal	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171290/grokade-screenshots/Snake_Trae_20250316_160017.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171931/grokade-screenshots/Snake_Trae_20250316_160016.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171932/grokade-screenshots/Snake_Trae_20250310_203401.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171933/grokade-screenshots/Snake_Trae_20250310_202321.png	f
dfba9261-3270-4ba2-9110-5103eb8c03c9	Breaking Balls	Break balls and feel calm	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171291/grokade-screenshots/Breaking_Balls_20250310_202532.png	https://makereal.tldraw.link/-wMNzXuU7igniDJ6oyhKW	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Sports	https://x.com/adityakabra	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171291/grokade-screenshots/Breaking_Balls_20250310_202532.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171936/grokade-screenshots/Breaking_Balls_20250316_155829.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171937/grokade-screenshots/Breaking_Balls_20250310_203409.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171938/grokade-screenshots/Breaking_Balls_20250316_155704.png	f
bcbbaf7b-bd8e-413d-b42b-e483d4dec771	Escape	A text-based escape room game	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171293/grokade-screenshots/Escape_Prison_Cell_20250310_202308.png	https://escape.puzzlesunlocked.com/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Puzzle	https://x.com/jamesckemp	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171293/grokade-screenshots/Escape_Prison_Cell_20250310_202308.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171940/grokade-screenshots/Escape_20250316_155856.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171942/grokade-screenshots/Escape_Prison_Cell_20250316_154642.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171944/grokade-screenshots/Escape_Prison_Cell_20250316_160225.png	f
ed450b52-5caa-492f-8790-d3c6b4f77fff	Ophidian	A short game that is basically Snake.	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171295/grokade-screenshots/Ophidian_20250310_202429.png	https://ophidian-offekt.vercel.app/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Strategy	https://x.com/drewvergara	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171295/grokade-screenshots/Ophidian_20250310_202429.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171953/grokade-screenshots/Ophidian_20250310_203259.png	\N	\N	f
f0e24ffc-e714-4da0-8510-35cfbb521ffb	Type Battles	Sharpen your typing skills, build up combos for a higher score, earn trophies and conquer all 10 levels to face the final boss...	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171297/grokade-screenshots/Type_Battles_20250310_202355.png	https://www.typebattles.com/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Platform,Action,Arcade	https://x.com/edwinhayward	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171297/grokade-screenshots/Type_Battles_20250310_202355.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171955/grokade-screenshots/Type_Battles_20250310_203330.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171956/grokade-screenshots/Type_Battles_20250316_155826.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171958/grokade-screenshots/Type_Battles_20250316_155827.png	f
e0173448-5bdb-410d-a47b-0174bf726c8b	Vibe Tanks	TRON style tank game. Play with your friends or against them in this fast paced game.	https://res.cloudinary.com/dxow1rafl/image/upload/v120250316/grokade-screenshots/Vibe_Tanks_20250316_154634.png	https://vibes.darefail.com/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-16 22:46:57.149	Racing,Shooter	https://x.com/darefailed	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171959/grokade-screenshots/Vibe_Tanks_20250316_160217.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171960/grokade-screenshots/Vibe_Tanks_20250316_155530.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171962/grokade-screenshots/Vibe_Tanks_20250316_154634.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171963/grokade-screenshots/Vibe_Tanks_20250310_202605.png	f
8ad6e622-f36f-42e3-aac7-92aa7d3a8288	Tanks AI	Experience the thrill of tank battles in this exciting game!	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171298/grokade-screenshots/Tanks_AI_20250316_155956.png	https://tanksai.com/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Action,Fighting	https://x.com/d4m1n	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171298/grokade-screenshots/Tanks_AI_20250316_155956.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171968/grokade-screenshots/Tanks_AI_20250310_203344.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171970/grokade-screenshots/Tanks_AI_20250310_202322.png	\N	f
788597c7-0923-4688-a425-6e694b0007d2	Mars Landing Simulator	Prepare for the ultimate Mars landing experience!	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171300/grokade-screenshots/Mars_Landing_Simulator_20250310_202521.png	https://marslanding.vercel.app/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Exploration,Simulation,Racing	https://x.com/hi_itsbey	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171300/grokade-screenshots/Mars_Landing_Simulator_20250310_202521.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171973/grokade-screenshots/Mars_Landing_Simulator_20250316_155831.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171974/grokade-screenshots/Mars_Landing_Simulator_20250316_155941.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171975/grokade-screenshots/Mars_Landing_Simulator_20250310_203240.png	f
8759da60-d5ce-42b4-b0aa-fafdbd345aa2	Macro Data Refinement	A web application that simulates the macro data refinement work from the TV show Severance	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171301/grokade-screenshots/Macro_Data_Refinement_20250310_203315.png	https://macro-data-refinement-five.vercel.app/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Simulation	https://x.com/mitchposts	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171301/grokade-screenshots/Macro_Data_Refinement_20250310_203315.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171978/grokade-screenshots/Macro_Data_Refinement_20250316_155858.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171979/grokade-screenshots/Macro_Data_Refinement_20250310_202508.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171980/grokade-screenshots/Macro_Data_Refinement_20250316_155830.png	f
25754fe0-22d6-4e01-b552-add4be72ae48	Tic-Tac Cricket	Unique and fun online game that combines Tic-Tac-Toe with the excitement of cricket!	\N	https://tictaccricket.netlify.app/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Sports,Arcade,Fighting	https://x.com/byteonwire	\N	\N	\N	\N	f
af707792-b791-4803-9d5d-dd83bf7fcc87	Archer wars	1 vs 1 archer war	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171302/grokade-screenshots/Archer_wars_20250316_155720.png	https://www.archerwars.xyz/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Shooter,Platform,Action	https://x.com/finvisual	\N	\N	\N	\N	f
f67f4c00-47fa-4ee3-a7bd-8a1bacd6f95e	Push the Box	In this reimagined Sokoban game, you embark on a journey of logic and space. As you gently guide the character to push the boxes towards their destinations, you...	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171305/grokade-screenshots/Push_the_Box_20250310_203156.png	https://boxgame2000.netlify.app/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Platform,Adventure,Puzzle	https://x.com/xiaochi2	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171305/grokade-screenshots/Push_the_Box_20250310_203156.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171986/grokade-screenshots/Push_the_Box_20250316_155959.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171988/grokade-screenshots/Push_the_Box_20250310_202331.png	\N	f
8cfc30a0-f692-4e4e-bdca-ad4c2c372cd1	Necropolis: Rise of the Undead	High paced and exciting vibe coded zombie first person shooter game	\N	https://shanelarson.com/games/necropolis	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Shooter,Action,Arcade	https://x.com/PeakGrizzly	\N	\N	\N	\N	f
d5663aac-ae60-473b-b36d-d00b4504dcc2	Jet Ski Simulation	Bring in the holiday vibes with this game. Play with your friends or against them in this fast paced game.	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171308/grokade-screenshots/Jet_Ski_Simulation_20250310_203311.png	https://jetski.cemilsevim.com/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-16 22:46:57.149	Simulation,Racing,Platform	https://x.com/cemilsvm	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171308/grokade-screenshots/Jet_Ski_Simulation_20250310_203311.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171652/grokade-screenshots/Jet_Ski_Simulation_20250310_202357.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171655/grokade-screenshots/Jet_Ski_Simulation_20250316_155916.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171659/grokade-screenshots/Jet_Ski_Simulation_20250316_155957.png	f
c10111fb-d178-4643-b837-7ef19bef8f41	Forest Escape	Escape from spirits in a haunted forest before they catch you!	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171309/grokade-screenshots/Forest_Escape_20250310_203148.png	https://www.escape.alexandre-grisey.fr/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Action	https://x.com/nomalex_	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171309/grokade-screenshots/Forest_Escape_20250310_203148.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172004/grokade-screenshots/Forest_Escape_20250310_202359.png	\N	\N	f
59b2393e-ebab-4d7e-b9c3-b2aaa0bd8513	Matrix Cube	Matrix Cube Memory is a challenging 3D memory game inspired by the digital world of The Matrix. Test your memory skills by remembering and repeating increasingl...	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171310/grokade-screenshots/Matrix_Cube_20250316_160114.png	https://matrixcube.netlify.app	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Educational	https://x.com/Akkorothone	\N	\N	\N	\N	f
dca78d28-45b4-44ea-9bc7-80baf7008641	Space Defenders	One shot a Space Invaders game like built with Sonnet 3.7	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171312/grokade-screenshots/Space_Defenders_20250316_155911.png	https://jasonleow.com/space-defenders/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Arcade,Sports,Action	https://x.com/jasonleowsg	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171312/grokade-screenshots/Space_Defenders_20250316_155911.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172007/grokade-screenshots/Space_Defenders_20250310_202420.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172009/grokade-screenshots/Space_Defenders_20250310_203352.png	\N	f
07d6775c-e242-4597-a44e-e22437a49459	Flappy Bird 3D	Flappy Bird reimagined as a 3D third person game	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171313/grokade-screenshots/Flappy_Bird_3D_20250316_155954.png	https://flappybird.purav.co	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Platform	https://x.com/notpurav	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171313/grokade-screenshots/Flappy_Bird_3D_20250316_155954.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172011/grokade-screenshots/Flappy_Bird_3D_20250316_155955.png	\N	\N	f
16d4082f-5b2f-4528-bc21-c105e46abbdf	Ad simulator	Capture the flag on a world full of ads	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171314/grokade-screenshots/Ad_simulator_20250310_203402.png	https://ad-simulator.com/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Simulation,Sports,Action	https://x.com/iagolast	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171314/grokade-screenshots/Ad_simulator_20250310_203402.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172014/grokade-screenshots/Ad_simulator_20250310_202432.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172016/grokade-screenshots/Ad_simulator_20250316_155719.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172017/grokade-screenshots/Ad_simulator_20250316_155500.png	f
9748c31e-640b-4263-b719-da3a8f08736e	Be a fish	Be a fish, eat other fish, become a bigger fish. Dive in and dominate the ocean!	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171316/grokade-screenshots/Be_a_fish_20250310_203323.png	https://www.be-a-fish.com/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Other	https://x.com/athcanft	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171316/grokade-screenshots/Be_a_fish_20250310_203323.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172023/grokade-screenshots/Be_a_fish_20250310_202455.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172026/grokade-screenshots/Be_a_fish_20250316_155618.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172029/grokade-screenshots/Be_a_fish_20250316_155527.png	f
b4d24777-f913-46b7-983d-88490a68e2c0	Aetherialdream	A beautiful and intuitive dream journal that helps you record, explore, and understand your dreams.	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171318/grokade-screenshots/Aetherialdream_20250310_202442.png	https://www.aetherialdream.com/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Adventure,Platform,Exploration	https://x.com/Kaberikram	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171318/grokade-screenshots/Aetherialdream_20250310_202442.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172033/grokade-screenshots/Aetherialdream_20250310_203225.png	\N	\N	f
4626e481-051b-4832-ba44-be606da797c6	Earth Simulation	Full earth simulation with climate, tectonic activity, evolution and civilization to factions, then burn it down with disaster scenarios. also includes earth te...	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171235/grokade-screenshots/Earth_Simulation_20250316_155504.png	https://o3-experiments-nextjs.fly.dev/earth	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Simulation,Action	https://x.com/rfitzpatrick_io	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171235/grokade-screenshots/Earth_Simulation_20250316_155504.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171650/grokade-screenshots/Earth_Simulation_20250310_202512.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171654/grokade-screenshots/Earth_Simulation_20250310_203237.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171658/grokade-screenshots/Earth_Simulation_20250316_155809.png	f
8f9010c4-d77b-4887-9cc3-0c9b7010c569	Falling Bubbles	Pop falling bubbles in a vibrant, fast-paced test of reflexes!	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171322/grokade-screenshots/Falling_Bubbles_20250310_203356.png	https://falling-bubbles.vercel.app/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-16 22:22:34.786	Shooter,Arcade,Sports	https://x.com/sagarsaija	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171322/grokade-screenshots/Falling_Bubbles_20250310_203356.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172047/grokade-screenshots/Falling_Bubbles_20250310_202329.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172048/grokade-screenshots/Falling_Bubbles_20250316_155507.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172050/grokade-screenshots/Falling_Bubbles_20250316_160024.png	f
6cb521f3-5336-4f75-8bbb-9b67d8b7ba3f	Tank	Tank is a multiplayer tank game. Play with your friends or against them in this fast paced game.	https://res.cloudinary.com/dxow1rafl/image/upload/v120250316/grokade-screenshots/Tank_20250316_154542.webp	https://tank.cemilsevim.com/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-16 22:46:57.149	Action,Fighting,Shooter	https://x.com/cemilsvm	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171298/grokade-screenshots/Tanks_AI_20250316_155956.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172061/grokade-screenshots/Tank_20250316_154633.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171539/grokade-screenshots/TankNarok_20250316_154646.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172064/grokade-screenshots/Tank_20250310_200527.jpg	f
83afb8c5-9e23-4fa8-9168-83decbd7978d	Fly Hi	Realistic flight simulator with a focus on realism and physics. Fly Hi is a game that allows you to experience the thrill of flying in a realistic way.	https://res.cloudinary.com/dxow1rafl/image/upload/v120250316/grokade-screenshots/Fly_Hi_20250316_154625.png	https://flyhi.netlify.app/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-16 22:46:57.149	Simulation	https://x.com/donvito	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172087/grokade-screenshots/Fly_Hi_20250310_202253.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172097/grokade-screenshots/Fly_Hi_20250316_160210.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172106/grokade-screenshots/Fly_Hi_20250316_154625.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172110/grokade-screenshots/Fly_Hi_20250310_202559.png	f
d2bc2c08-c7b5-47b7-b45b-fa3b5b2e8f36	GTAi	A GTA-inspired game. Drive/walk around and explore the city in singleplayer mode	https://res.cloudinary.com/dxow1rafl/image/upload/v120250316/grokade-screenshots/GTAi_20250316_154544.webp	https://gtai.wherenomadsgo.com/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-16 22:46:57.149	Racing,Shooter,Action	https://x.com/fabianbuilds	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172112/grokade-screenshots/GTAi_20250310_202551.jpg	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172113/grokade-screenshots/GTAi_20250316_154544.jpg	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172114/grokade-screenshots/GTAi_20250316_160129.jpg	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172115/grokade-screenshots/GTAi_20250310_201622.jpg	f
9b149ef6-7d84-4edc-8283-8b5522ce3518	V1be city	Shoot enemies in a city in singleplayer mode	https://res.cloudinary.com/dxow1rafl/image/upload/v120250316/grokade-screenshots/V1be_city_20250316_154545.webp	https://vibescity.manta.so/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-16 22:46:57.149	Action,Shooter	https://x.com/gabriel__xyz	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172118/grokade-screenshots/V1be_city_20250316_154545.jpg	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172119/grokade-screenshots/V1be_city_20250310_200530.jpg	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172120/grokade-screenshots/V1be_city_20250310_200907.jpg	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172122/grokade-screenshots/V1be_city_20250310_201623.jpg	f
4b3fa1ed-a7fa-4185-9f03-519c76913aca	FlyVibe	Flappy Bird like game but with paper plane and different modes	https://res.cloudinary.com/dxow1rafl/image/upload/v120250316/grokade-screenshots/FlyVibe_20250316_154548.webp	https://farez.github.io/flyvibe/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-16 22:46:57.149	Strategy	https://x.com/farez	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172147/grokade-screenshots/FlyVibe_20250316_160132.jpg	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172147/grokade-screenshots/FlyVibe_20250316_154548.jpg	\N	\N	f
0dd8000b-48c2-4f63-addc-f4e908dd939e	Samurai Battle	Samurai Battle	\N	https://vibegames.cc/browse/samurai-battle	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-16 22:46:57.149	Action,Fighting,Simulation	\N	\N	\N	\N	\N	f
46250f21-9a73-4146-88f4-513a1c5f99d9	Tank Battle	Tank Battle	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171323/grokade-screenshots/Enhanced_Tank_Battle_Game_20250316_155746.png	https://vibegames.cc/browse/tank-battle	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-16 22:46:57.149	Action,Fighting,Simulation	\N	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171323/grokade-screenshots/Enhanced_Tank_Battle_Game_20250316_155746.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172150/grokade-screenshots/Enhanced_Tank_Battle_Game_20250310_203406.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172152/grokade-screenshots/Enhanced_Tank_Battle_Game_20250310_202342.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172153/grokade-screenshots/Enhanced_Tank_Battle_Game_20250316_155920.png	f
18b64c24-3028-4d04-98e5-c4382f0c8cd0	Summer Afternoon	Beautiful chill exploration game with Ghibli nostalgia. Procedurally generated environment with chill music. Human made.	https://res.cloudinary.com/dxow1rafl/image/upload/v120250316/grokade-screenshots/Summer_Afternoon_20250316_154624.png	https://vlucendo.com/play/summer-afternoon	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-16 22:46:57.149	Exploration	https://x.com/vlucendo	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172155/grokade-screenshots/Summer_Afternoon_20250310_202557.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172157/grokade-screenshots/Summer_Afternoon_20250310_202251.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172159/grokade-screenshots/Summer_Afternoon_20250316_154624.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172161/grokade-screenshots/Summer_Afternoon_20250316_160208.png	f
4bebe6a9-db56-453e-a85d-0400cb5a08f5	Slow Roads	Drive around the Scottish countryside in this beautifully made game. Human Made.	https://res.cloudinary.com/dxow1rafl/image/upload/v120250316/grokade-screenshots/Slow_Roads_20250316_154624.png	https://slowroads.io/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-16 22:46:57.149	Racing	https://x.com/anslogen	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172163/grokade-screenshots/Slow_Roads_20250310_202558.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172165/grokade-screenshots/Slow_Roads_20250316_154624.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172167/grokade-screenshots/Slow_Roads_20250316_160209.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172170/grokade-screenshots/Slow_Roads_20250310_202252.png	f
61f434ad-2388-45de-b373-b561be63590b	Robotic Surge Shooter	Arcade style space shooter with a focus on fast-paced gameplay and smooth controls.	https://res.cloudinary.com/dxow1rafl/image/upload/v120250316/grokade-screenshots/Robotic_Surge_Shooter_20250316_154627.png	https://roboticsurge.itch.io/shooter	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-16 22:46:57.149	Action,Shooter,Arcade	https://x.com/jagger_sa	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172188/grokade-screenshots/Robotic_Surge_Shooter_20250316_160211.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172189/grokade-screenshots/Robotic_Surge_Shooter_20250310_202254.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172190/grokade-screenshots/Robotic_Surge_Shooter_20250316_154627.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172192/grokade-screenshots/Robotic_Surge_Shooter_20250310_202600.png	f
3e78f568-8737-4c77-a46b-e326470acb70	XForce	Space shooter with a fast paced gameplay and a focus on skill and precision.	https://res.cloudinary.com/dxow1rafl/image/upload/v120250316/grokade-screenshots/XForce_20250316_154629.png	https://xforcegame.com/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-16 22:46:57.149	Action,Educational,Racing	https://x.com/Daniel_Farinax	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172194/grokade-screenshots/XForce_20250316_160212.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172197/grokade-screenshots/XForce_20250316_154629.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172200/grokade-screenshots/XForce_20250310_202255.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172202/grokade-screenshots/XForce_20250310_202601.png	f
24d8d342-b1d7-40ee-8ad4-6c5636c04661	Stick Cricket	Hardest game of cricket you'll ever play.	https://res.cloudinary.com/dxow1rafl/image/upload/v120250316/grokade-screenshots/Stick_Cricket_20250316_154630.png	https://stick-cricket.vercel.app/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-16 22:46:57.149	Fighting	https://x.com/saikatkrdey	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172204/grokade-screenshots/Stick_Cricket_20250310_202256.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172207/grokade-screenshots/Stick_Cricket_20250316_160213.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172209/grokade-screenshots/Stick_Cricket_20250316_154630.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172211/grokade-screenshots/Stick_Cricket_20250310_202602.png	f
a3235777-29c9-418d-8b3d-bec551b9e174	Open Road	Drive or Fly around the world in this open world game. Choose your own mode of travel.	https://res.cloudinary.com/dxow1rafl/image/upload/v120250316/grokade-screenshots/Open_Road_20250316_154631.png	https://openroad-game.vercel.app/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-16 22:46:57.149	Exploration,Racing	https://x.com/aaronbesson	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172213/grokade-screenshots/Open_Road_20250316_154631.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172214/grokade-screenshots/Open_Road_20250310_202603.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172216/grokade-screenshots/Open_Road_20250310_202257.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172217/grokade-screenshots/Open_Road_20250316_160214.png	f
2bfa4820-05e8-429d-91db-fd43914f98f9	Swim Around	Swim around the world in this open underwater world game	https://res.cloudinary.com/dxow1rafl/image/upload/v120250316/grokade-screenshots/Swim_Around_20250316_154631.png	https://swimaround.io/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-16 22:46:57.149	Action	https://x.com/RyanEndacott	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172219/grokade-screenshots/Swim_Around_20250310_202258.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172221/grokade-screenshots/Swim_Around_20250316_154631.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172222/grokade-screenshots/Swim_Around_20250310_202603.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172224/grokade-screenshots/Swim_Around_20250316_160215.png	f
c60de4b9-bb22-4b66-ba31-8a6754f8a876	Space Balls	Fast paced game of command and destruction. Command an army of units and destroy smaller units to grow your army.	https://res.cloudinary.com/dxow1rafl/image/upload/v120250316/grokade-screenshots/Space_Balls_20250316_154632.png	https://spaceballs.io/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-16 22:46:57.149	Strategy,Racing,Sports	https://x.com/IndieJayCodes	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172225/grokade-screenshots/Space_Balls_20250316_160216.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172226/grokade-screenshots/Space_Balls_20250316_154632.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172228/grokade-screenshots/Space_Balls_20250310_202604.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172229/grokade-screenshots/Space_Balls_20250310_202258.png	f
86c45ba5-ab0f-452b-b1e8-877a898bec14	Pixel2DFight	Fast paced arcade shooter. Shoot the squares and grow your score.	https://res.cloudinary.com/dxow1rafl/image/upload/v120250316/grokade-screenshots/Pixel2DFight_20250316_154638.png	https://pixel2dfight.vercel.app/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-16 22:46:57.149	Action,Arcade,Shooter	https://x.com/bladeemaxxi	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172231/grokade-screenshots/Pixel2DFight_20250316_154638.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172232/grokade-screenshots/Pixel2DFight_20250310_202609.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172234/grokade-screenshots/Pixel2DFight_20250310_202304.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172236/grokade-screenshots/Pixel2DFight_20250316_160221.png	f
1c44b058-5546-4826-ae5b-262763ad2a31	Escape Prison Cell	Well designed and executed escape room. It's harder than you think	https://res.cloudinary.com/dxow1rafl/image/upload/v120250316/grokade-screenshots/Escape_Prison_Cell_20250316_154642.png	https://escape-prison-cell.vercel.app/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-16 22:46:57.149	Puzzle	https://x.com/jamesckemp	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171293/grokade-screenshots/Escape_Prison_Cell_20250310_202308.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171942/grokade-screenshots/Escape_Prison_Cell_20250316_154642.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171944/grokade-screenshots/Escape_Prison_Cell_20250316_160225.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171947/grokade-screenshots/Escape_Prison_Cell_20250310_202613.png	f
408320e2-1adb-470a-b015-6e39bf8a5990	Racing Cart	Race around the track, but be sure not to hit the kerb!	https://res.cloudinary.com/dxow1rafl/image/upload/v120250316/grokade-screenshots/Racing_Cart_20250316_154644.png	https://racingcart.vercel.app	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-17 19:29:16.528	Racing	https://x.com/pat_codes	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171229/grokade-screenshots/Racing_Cart_20250316_160228.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171637/grokade-screenshots/Racing_Cart_20250316_154644.png	\N	\N	f
eccd75c9-812b-4464-b542-8dc1c4fa94f9	WW2 Dogfight Arena	Most beautiful multiplayer dogfight game. Play with your friends or against them in this fast paced game.	https://res.cloudinary.com/dxow1rafl/image/upload/v120250316/grokade-screenshots/WW2_Dogfight_Arena_20250316_154634.png	https://fly.zullo.fun/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-17 19:41:34.534	Fighting,Action,Racing	https://x.com/NicolasZu	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171849/grokade-screenshots/WW2_Dogfight_Arena_20250310_202301.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171851/grokade-screenshots/WW2_Dogfight_Arena_20250316_160218.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171853/grokade-screenshots/WW2_Dogfight_Arena_20250310_202606.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171856/grokade-screenshots/WW2_Dogfight_Arena_20250316_154634.png	f
7f37cb28-0731-4c2a-b1b9-16cd56a57367	Hot Air Balloon	Take a chill ride on a hotair baloon amoung the snowy mountains	https://res.cloudinary.com/dxow1rafl/image/upload/v120250316/grokade-screenshots/Hot_Air_Balloon_20250316_154547.webp	https://www.hotairvibe.com/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-17 19:41:34.534	Sports	https://x.com/SieversJosua	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172126/grokade-screenshots/Hot_Air_Balloon_20250316_154547.jpg	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172127/grokade-screenshots/Hot_Air_Balloon_20250310_200532.jpg	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172128/grokade-screenshots/Hot_Air_Balloon_20250310_202554.jpg	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172129/grokade-screenshots/Hot_Air_Balloon_20250316_160223.png	f
9359a360-70c0-43ad-bceb-9912f7d134da	Flee Battle	Flee the battle!	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171306/grokade-screenshots/Flee_Battle_20250310_203340.png	https://languagedungeon.com/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:22:34.786	2025-03-17 19:42:50.818	Action,Fighting	https://x.com/maxhertan	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171306/grokade-screenshots/Flee_Battle_20250310_203340.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171990/grokade-screenshots/Flee_Battle_20250316_155716.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171991/grokade-screenshots/Flee_Battle_20250310_202412.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171993/grokade-screenshots/Flee_Battle_20250316_155718.png	f
193935c5-ac96-4664-bcc0-9869b84e1548	Wildy Royale	Join a team or play alone and defend against waves of zombies in this first-person battle royale game.	https://res.cloudinary.com/dxow1rafl/image/upload/v120250316/grokade-screenshots/Wildy_Royale_20250316_154636.png	https://www.wildyroyale.com/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-17 22:19:40.469	Action,Fighting,Sports	https://x.com/nathansrobinson	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171775/grokade-screenshots/Wildy_Royale_20250310_202608.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171778/grokade-screenshots/Wildy_Royale_20250310_202302.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171781/grokade-screenshots/Wildy_Royale_20250316_154636.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171783/grokade-screenshots/Wildy_Royale_20250316_155702.png	t
20f4e68a-8d53-454a-a405-d40fa30e4674	Race Viberz	Race around the track with your mates!	https://res.cloudinary.com/dxow1rafl/image/upload/v120250316/grokade-screenshots/Race_Viberz_20250316_154641.png	https://raceviberz.vercel.app/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-17 22:20:08.614	Racing	https://x.com/LoukilAymen	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172264/grokade-screenshots/Race_Viberz_20250316_154641.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172266/grokade-screenshots/Race_Viberz_20250310_202307.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172268/grokade-screenshots/Race_Viberz_20250316_160225.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172270/grokade-screenshots/Race_Viberz_20250310_202612.png	t
91698f39-9bc5-464f-8aaf-e73a8a0f3cea	Arcade City	This is a game within a game. You could just fly around the neon city and then do some speed racing on a 3d track!	https://res.cloudinary.com/dxow1rafl/image/upload/v120250316/grokade-screenshots/Arcade_City_20250316_154644.png	https://arcade.0xrome.com/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-17 23:30:44.919	Racing,Arcade	https://x.com/0xRome	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171227/grokade-screenshots/Arcade_City_20250316_160227.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171626/grokade-screenshots/Arcade_City_20250310_202615.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171631/grokade-screenshots/Arcade_City_20250316_154644.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171634/grokade-screenshots/Arcade_City_20250310_202310.png	t
8074fbb7-fe43-4c9b-aa2b-839438670652	Cowboy	Gallop through a wild west street and shoot at things!	https://res.cloudinary.com/dxow1rafl/image/upload/v120250316/grokade-screenshots/Cowboy_20250316_154626.png	https://pseudokid.itch.io/cowboys	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-17 22:06:50.32	Action,Shooter	https://x.com/pseudokid	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171713/grokade-screenshots/Cowboy_Shooter_20250316_155637.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171715/grokade-screenshots/Cowboy_Shooter_20250316_160104.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171716/grokade-screenshots/cowboy_shooter_20250310_200904.jpg	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171717/grokade-screenshots/cowboy_shooter_20250316_154541.jpg	t
2272eed7-d25d-496f-aece-6aa7cbaac8bd	Vibe Sail	Chill out and sail the waves in this relaxing game. Vibe Sail is a simple, calming game that allows you to relax and enjoy the beautiful scenery.	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171239/grokade-screenshots/Vibe_Sail_20250316_160207.png	https://vibesail.com/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-17 22:06:50.648	Arcade,Simulation	https://x.com/NicolaManzini	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171239/grokade-screenshots/Vibe_Sail_20250316_160207.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171670/grokade-screenshots/Vibe_Sail_20250316_155531.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171672/grokade-screenshots/Vibe_Sail_20250310_202556.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171674/grokade-screenshots/Vibe_Sail_20250310_203404.png	t
708299c8-25f6-45c6-ad30-3dc8592775d4	TankNarok	Multiplayer tank battle game where you compete against other players in real-time combat. Maneuver your tank, avoid enemy fire, and destroy your opponents!	https://res.cloudinary.com/dxow1rafl/image/upload/v120250316/grokade-screenshots/TankNarok_20250316_154646.png	https://tanks.rpaby.pw/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-17 22:06:50.801	Fighting,Action,Shooter	https://x.com/paulwes_pw	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171539/grokade-screenshots/TankNarok_20250316_154646.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171541/grokade-screenshots/Tanknarok_20250316_155457.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171542/grokade-screenshots/TankNarok_20250316_160229.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742171544/grokade-screenshots/Tanknarok_20250316_155815.png	t
054009be-8fa3-4bdb-a853-57f5c355583f	PingPongAI	Ping Pong game	https://res.cloudinary.com/dxow1rafl/image/upload/v1741710569/grokade-screenshots/game_66_1741710568864_PingPongAI_20250310_095514.png.png	https://pingpongai.vercel.app/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 02:13:33.759	2025-03-17 22:19:40.469	Arcade	\N	\N	\N	\N	\N	f
bfbf5cd7-c44b-4054-a1a8-71455c04f29d	Surviber FPS	Endless Horde Survival Shooter. It's more difficult than it looks	https://res.cloudinary.com/dxow1rafl/image/upload/v120250316/grokade-screenshots/Surviber_FPS_20250316_154640.png	https://surviber-fps.vercel.app/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-17 22:20:08.614	Shooter,Action,Survival	https://x.com/0xyardev	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172258/grokade-screenshots/Surviber_FPS_20250310_202307.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172259/grokade-screenshots/Surviber_FPS_20250316_154640.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172261/grokade-screenshots/Surviber_FPS_20250310_202612.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172262/grokade-screenshots/Surviber_FPS_20250316_160224.png	t
8d3ebac9-6a26-4269-96c4-d6da0514d5b1	ShellShock Showdown	Tank shooter FPS, driver around and unleash mayhem!	https://res.cloudinary.com/dxow1rafl/image/upload/v120250316/grokade-screenshots/ShellShock_Showdown_20250316_154639.png	https://shellshockshowdown.itch.io/game	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-17 23:30:22.459	Shooter,Action,Racing	https://x.com/what_the_func	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172242/grokade-screenshots/ShellShock_Showdown_20250310_202610.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172250/grokade-screenshots/ShellShock_Showdown_20250316_160222.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172253/grokade-screenshots/ShellShock_Showdown_20250310_202305.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172256/grokade-screenshots/ShellShock_Showdown_20250316_154639.png	f
bbbf2d80-4dba-4faf-a777-09cb88159bc1	Fly Pieter	A fun free-to-play MMO flight sim, 100% made with Al, without loading screens and GBs of updates every time you wanna play. OG	https://res.cloudinary.com/dxow1rafl/image/upload/v120250316/grokade-screenshots/Fly_Pieter_20250316_154622.png	https://fly.pieter.com/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	2025-03-16 22:46:57.149	2025-03-17 22:25:41.098	Simulation	https://x.com/levelsio	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172053/grokade-screenshots/Fly_Pieter_20250310_202250.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172054/grokade-screenshots/Fly_Pieter_20250316_160206.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172056/grokade-screenshots/Fly_Pieter_20250310_202556.png	https://res.cloudinary.com/dxow1rafl/image/upload/v1742172058/grokade-screenshots/Fly_Pieter_20250316_154622.png	t
\.


--
-- Data for Name: page_views; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.page_views (id, path, "userId", "userAgent", referer, "timestamp") FROM stdin;
e36cd4fa-cb02-4d53-ac82-b2b92a5afbe7	/	\N	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/131.0.6778.0 Safari/537.36		2025-03-18 04:20:26.81
f43c83ce-7b45-4a44-a151-ffb473131c00	/	\N	Mozilla/5.0 (Linux; Android 7.0; Moto G (4)) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4695.0 Mobile Safari/537.36 Chrome-Lighthouse		2025-03-18 04:20:29.913
464d1c10-0895-49d7-bb1c-204e07ffbb87	/	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36		2025-03-18 04:25:07.84
64b89a8a-0181-40a4-bdfa-8eefa50fb2e2	/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36		2025-03-18 04:25:08.223
82d21835-8144-4fb1-b3f2-389efa4eb56e	/admin/analytics/	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36		2025-03-18 04:29:00.949
b5d13347-895b-4ce9-9699-a6a814807e9f	/admin/analytics/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36		2025-03-18 04:29:02.379
20bef97e-6943-4a03-a138-921da87ee927	/dashboard/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36		2025-03-18 04:29:13.175
c81a8088-84d6-43a7-a725-0269e31bbc0e	/admin/analytics/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36		2025-03-18 04:29:21.667
05bd374f-fb5b-43ab-bd5f-4cf760c1229d	/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36		2025-03-18 04:29:58.996
47eeef54-3a85-4d5c-a593-aced252e34b6	/	\N	Mozilla/5.0 (Linux; Android 7.0; Moto G (4)) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4695.0 Mobile Safari/537.36 Chrome-Lighthouse		2025-03-18 04:30:00.119
2491c59f-6d84-4cd8-833a-f2e7fa752c77	/game/bf456723-0c50-448d-9732-623f581da6a0/	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36	https://grokade.com/	2025-03-18 04:30:05.781
2ca29689-236e-4f92-9f43-1665625950b2	/game/bf456723-0c50-448d-9732-623f581da6a0/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36	https://grokade.com/	2025-03-18 04:30:06.737
64474016-ff9d-4023-aeff-51538d4eb348	/coming-soon/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36	https://grokade.com/	2025-03-18 04:30:14.083
8601882e-7a9c-4f4b-9908-1048f3df23d1	/rankings/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36	https://grokade.com/	2025-03-18 04:30:15.625
a1ebaa7a-f46c-4ac8-8aad-bed2b7741078	/coming-soon/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36	https://grokade.com/	2025-03-18 04:30:16.311
35b2d4ab-740b-487f-aa3d-15f76d1d27ed	/rankings/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36	https://grokade.com/	2025-03-18 04:30:18.73
072b6073-de30-438a-9a77-c5af462f2bbf	/admin/analytics/	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36		2025-03-18 04:32:33.473
90baab7e-4896-4e59-be48-f19c37da397d	/admin/analytics/	a6c246ae-f84b-4c43-87b4-05db6b55afc3	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36		2025-03-18 04:32:33.71
\.


--
-- Data for Name: sponsors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sponsors (id, name, description, "logoUrl", website, "createdAt", "updatedAt") FROM stdin;
bbbc6247-782a-4f1b-8f60-cd5e3a2d69fd	GitHub	Development platform	https://res.cloudinary.com/dxow1rafl/image/upload/sponsors/github-logo.png	https://github.com	2025-03-16 02:05:31.002	2025-03-16 02:34:10.65
20de7838-dc4a-4dc4-be04-300db35feb1d	npm	Package registry	https://res.cloudinary.com/dxow1rafl/image/upload/sponsors/npm-logo.png	https://www.npmjs.com	2025-03-16 02:05:31.525	2025-03-16 02:34:10.983
7e702654-f6c1-45c3-af6c-13fad1f01923	Python	Programming language	https://res.cloudinary.com/dxow1rafl/image/upload/sponsors/python-logo.png	https://python.org	2025-03-16 02:05:31.678	2025-03-16 02:34:11.101
f031ffa6-d698-44e3-8e55-8d07afb91bf0	Ubuntu	Operating system	https://res.cloudinary.com/dxow1rafl/image/upload/sponsors/ubuntu-logo.png	https://ubuntu.com	2025-03-16 02:05:31.831	2025-03-16 02:34:11.21
af0d9214-fa29-4410-a635-3b691e573417	Laravel	Backend framework provider	https://res.cloudinary.com/dxow1rafl/image/upload/sponsors/laravel-logo.svg	https://laravel.com	2025-03-16 02:05:29.586	2025-03-16 02:34:09.649
a7f9f60f-0ca9-448d-966f-884103f27c87	React	Frontend library partner	https://res.cloudinary.com/dxow1rafl/image/upload/sponsors/react-logo.png	https://reactjs.org	2025-03-16 02:05:29.902	2025-03-16 02:34:09.805
d1926221-d51b-4e57-bf71-43175556c9f8	Node.js	Server runtime environment	https://res.cloudinary.com/dxow1rafl/image/upload/sponsors/nodejs-logo.png	https://nodejs.org	2025-03-16 02:05:30.053	2025-03-16 02:34:09.91
c3faa617-490e-4356-8a1c-3a18ea929e1b	AWS	Cloud infrastructure partner	https://res.cloudinary.com/dxow1rafl/image/upload/sponsors/aws-logo.png	https://aws.amazon.com	2025-03-16 02:05:30.217	2025-03-16 02:34:10.019
b0081589-dc99-4c90-809a-13bc32fc99ea	DigitalOcean	Hosting services provider	https://res.cloudinary.com/dxow1rafl/image/upload/sponsors/digitalocean-logo.png	https://digitalocean.com	2025-03-16 02:05:30.392	2025-03-16 02:34:10.149
ad66957f-8770-41c8-a88d-3ae7198bd944	MongoDB	Database solutions	https://res.cloudinary.com/dxow1rafl/image/upload/sponsors/mongodb-logo.png	https://mongodb.com	2025-03-16 02:05:30.544	2025-03-16 02:34:10.274
d74600e3-64c7-43fd-a61b-3f51db746f5a	Stripe	Payment processing	https://res.cloudinary.com/dxow1rafl/image/upload/sponsors/stripe-logo.png	https://stripe.com	2025-03-16 02:05:30.697	2025-03-16 02:34:10.418
5c4420bd-641f-4dd1-872b-3427552fad6c	Docker	Container platform	https://cdn4.iconfinder.com/data/icons/logos-and-brands/512/97_Docker_logo_logos-512.png	https://docker.com	2025-03-16 02:05:31.178	2025-03-16 02:40:47.015
66f36e27-f85c-4e3d-a2e9-1ee5ab23623c	Google Cloud	Cloud services partner	https://cdn.worldvectorlogo.com/logos/google-cloud-1.svg	https://cloud.google.com	2025-03-16 02:05:30.85	2025-03-16 02:40:47.216
\.


--
-- Data for Name: subscribers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subscribers (id, email, name, status, "createdAt", "updatedAt") FROM stdin;
86b866cc-4663-4f36-a37b-c3d4d4559253	james@veruca.io	\N	active	2025-03-18 02:16:58.3	2025-03-18 02:16:58.3
\.


--
-- Data for Name: user_achievements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_achievements (id, "userId", "achievementId", "unlockedAt") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, email, "displayName", password, "createdAt", "updatedAt", role) FROM stdin;
37211933-f036-4942-a90a-b4d5e34e5a26	test	test@example.com	test	$2b$10$XrHbEsVWQegDgZ8iFAjgpOgnH.Liaewt4/D5nP7CcrJ0/i09XfTX2	2025-03-15 00:38:17.422	2025-03-15 00:38:17.422	REGULAR
aa737d17-fa89-402a-83cc-ae911bb0730d	Testing	Testing@test.com	Testing	$2b$10$MR5w3Hi9clJ8KZy3In1gUeuQAisqkC8l6w6kewULtKv6FcguEPc1a	2025-03-15 01:04:33.189	2025-03-15 01:04:33.189	REGULAR
a6c246ae-f84b-4c43-87b4-05db6b55afc3	admin	admin@grokade.com	Admin User	$2b$10$KQQRQjkpMfSuuYVpdnAZBe35b73PYmsdK3METy1GONsG1qkPEjyuG	2025-03-14 21:19:05.893	2025-03-18 04:09:47.562	ADMIN
406e20cd-07f9-4227-9a14-cba2e292afa4	aigamelord	aigamelord@gmail.com	aigamelord	$2b$10$wAGz8dwjQYYAXQr7yx/JbuJ4Yb8DdHgSHMAwJf0aGz0uR4Gk.btz6	2025-03-15 00:44:10.731	2025-03-18 04:09:53.674	ADMIN
\.


--
-- Name: game_favorites game_favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.game_favorites
    ADD CONSTRAINT game_favorites_pkey PRIMARY KEY ("userId", "gameId");


--
-- Name: game_metrics game_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.game_metrics
    ADD CONSTRAINT game_metrics_pkey PRIMARY KEY (id);


--
-- Name: games games_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.games
    ADD CONSTRAINT games_pkey PRIMARY KEY (id);


--
-- Name: page_views page_views_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.page_views
    ADD CONSTRAINT page_views_pkey PRIMARY KEY (id);


--
-- Name: sponsors sponsors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sponsors
    ADD CONSTRAINT sponsors_pkey PRIMARY KEY (id);


--
-- Name: subscribers subscribers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscribers
    ADD CONSTRAINT subscribers_pkey PRIMARY KEY (id);


--
-- Name: user_achievements user_achievements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_achievements
    ADD CONSTRAINT user_achievements_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: game_metrics_gameId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "game_metrics_gameId_key" ON public.game_metrics USING btree ("gameId");


--
-- Name: subscribers_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX subscribers_email_key ON public.subscribers USING btree (email);


--
-- Name: user_achievements_userId_achievementId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "user_achievements_userId_achievementId_key" ON public.user_achievements USING btree ("userId", "achievementId");


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: users_username_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_username_key ON public.users USING btree (username);


--
-- Name: game_favorites game_favorites_gameId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.game_favorites
    ADD CONSTRAINT "game_favorites_gameId_fkey" FOREIGN KEY ("gameId") REFERENCES public.games(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: game_favorites game_favorites_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.game_favorites
    ADD CONSTRAINT "game_favorites_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: game_metrics game_metrics_gameId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.game_metrics
    ADD CONSTRAINT "game_metrics_gameId_fkey" FOREIGN KEY ("gameId") REFERENCES public.games(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: games games_authorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.games
    ADD CONSTRAINT "games_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: page_views page_views_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.page_views
    ADD CONSTRAINT "page_views_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: user_achievements user_achievements_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_achievements
    ADD CONSTRAINT "user_achievements_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT CREATE ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

